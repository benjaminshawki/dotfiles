#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#define GRID_SIZE 10
#define NUM_SHIPS 3

typedef struct {
  int length;
  int hits;
  bool sunk;
  int start_x;
  int start_y;
  char direction;
} Ship;

typedef struct {
  char **cells;
  Ship ships[NUM_SHIPS];
} Grid;

void init_grid(Grid *grid) {
  grid->cells = calloc(GRID_SIZE, sizeof(char *));
  if (grid->cells == NULL) {
    fprintf(stderr, "Failed to allocate memory for grid cells.\n");
    exit(EXIT_FAILURE);
  }

  for (int i = 0; i < GRID_SIZE; ++i) {
    grid->cells[i] = calloc(GRID_SIZE, sizeof(char));
    if (grid->cells[i] == NULL) {
      fprintf(stderr, "Failed to allocate memory for grid->cells[%d].\n", i);
      exit(EXIT_FAILURE);
    }
  }
}

void display_grid(Grid *grid, bool during_attack) {
  if (grid) {
    printf("    0 1 2 3 4 5 6 7 8 9 X\n    - - - - - - - - - -\n");
  }
  for (int i = 0; i < GRID_SIZE; ++i) {
    printf("%d | ", i);
    for (int j = 0; j < GRID_SIZE; ++j) {
      if (during_attack) {
        if (grid->cells[i][j] == 'X') {
          printf("X ");
        } else if (grid->cells[i][j] == 'O') {
          printf("O ");
        } else {
          printf("? ");
        }
      } else {
        if (grid->cells[i][j] != 0) {
          printf("%c ", grid->cells[i][j]);
        } else {
          printf(". ");
        }
      }
    }
    printf("\n");
  }
  printf("Y\n=========================\n");
}

bool is_valid_direction(char direction) {
  direction = tolower(direction);
  return direction == 'n' || direction == 'e' || direction == 's' ||
         direction == 'w';
}

bool are_valid_coordinates(int x, int y) {
  return x >= 0 && x < GRID_SIZE && y >= 0 && y < GRID_SIZE;
}

bool place_ship(Grid *grid, Ship *ship, int start_x, int start_y,
                char direction) {
  int i;
  if (direction == 'e') {
    if (start_x + ship->length > GRID_SIZE)
      return false;
    for (i = 0; i < ship->length; ++i) {
      if (grid->cells[start_y][start_x + i] != 0)
        return false;
    }
    for (i = 0; i < ship->length; ++i) {
      grid->cells[start_y][start_x + i] = 'S';
    }
  } else if (direction == 'w') {
    if (start_x - ship->length + 1 < 0)
      return false;
    for (i = 0; i < ship->length; ++i) {
      if (grid->cells[start_y][start_x - i] != 0)
        return false;
    }
    for (i = 0; i < ship->length; ++i) {
      grid->cells[start_y][start_x - i] = 'S';
    }
  } else if (direction == 'n') {
    if (start_y - ship->length + 1 < 0)
      return false;
    for (i = 0; i < ship->length; ++i) {
      if (grid->cells[start_y - i][start_x] != 0)
        return false;
    }
    for (i = 0; i < ship->length; ++i) {
      grid->cells[start_y - i][start_x] = 'S';
    }
  } else if (direction == 's') {
    if (start_y + ship->length > GRID_SIZE)
      return false;
    for (i = 0; i < ship->length; ++i) {
      if (grid->cells[start_y + i][start_x] != 0)
        return false;
    }
    for (i = 0; i < ship->length; ++i) {
      grid->cells[start_y + i][start_x] = 'S';
    }
  } else {
    return false; // Invalid direction
  }

  ship->start_x = start_x;
  ship->start_y = start_y;
  ship->direction = direction;

  return true;
}

void get_user_input_for_ship_placement(Grid *grid, Ship *ship, int ship_index) {
  int x, y;
  char direction;

  while (true) {
    printf("Enter coordinates and direction to place ship %d (length %d) (x y "
           "direction): \n",
           ship_index, ship->length);

    while (true) {
      printf("X: ");
      scanf("%d", &x);
      if (!are_valid_coordinates(x, 0)) {
        printf("Invalid X coordinate. Coordinates must be within the grid "
               "(0-%d). Try again.\n",
               GRID_SIZE - 1);
        continue;
      }

      printf("Y: ");
      scanf("%d", &y);
      if (!are_valid_coordinates(0, y)) {
        printf("Invalid Y coordinate. Coordinates must be within the grid "
               "(0-%d). Try again.\n",
               GRID_SIZE - 1);
        continue;
      }

      break;
    }

    while (true) {
      printf("Direction (N, E, S, W): ");
      scanf(" %c", &direction);
      direction = tolower(direction);
      if (is_valid_direction(direction)) {
        break;
      } else {
        printf("Invalid direction. Direction must be one of N, E, S, W (case "
               "insensitive). Try again.\n");
      }
    }

    if (place_ship(grid, ship, x, y, direction)) {
      break;
    } else {
      printf("Invalid placement. Try again.\n");
    }
  }
}

void mark_ship_hit(Grid *grid, int x, int y) {
  for (int i = 0; i < NUM_SHIPS; ++i) {
    Ship *ship = &grid->ships[i];
    int hit = 0;

    if (ship->direction == 'e') {
      if (y == ship->start_y && x >= ship->start_x &&
          x < ship->start_x + ship->length) {
        hit = 1;
      }
    } else if (ship->direction == 'w') {
      if (y == ship->start_y && x <= ship->start_x &&
          x > ship->start_x - ship->length) {
        hit = 1;
      }
    } else if (ship->direction == 'n') {
      if (x == ship->start_x && y <= ship->start_y &&
          y > ship->start_y - ship->length) {
        hit = 1;
      }
    } else if (ship->direction == 's') {
      if (x == ship->start_x && y >= ship->start_y &&
          y < ship->start_y + ship->length) {
        hit = 1;
      }
    }

    if (hit) {
      ship->hits++;
      if (ship->hits == ship->length) {
        ship->sunk = true;
        printf("Ship %d sunk!\n", i);
      }
      break;
    }
  }
}

void get_user_input_for_attack(Grid *grid) {
  int x, y;

  while (true) {
    printf("Enter coordinates to attack (x y): \n");

    while (true) {
      printf("X: ");
      scanf("%d", &x);
      if (!are_valid_coordinates(x, 0)) {
        printf("Invalid X coordinate. Coordinates must be within the grid "
               "(0-%d). Try again.\n",
               GRID_SIZE - 1);
        continue;
      }

      printf("Y: ");
      scanf("%d", &y);
      if (!are_valid_coordinates(0, y)) {
        printf("Invalid Y coordinate. Coordinates must be within the grid "
               "(0-%d). Try again.\n",
               GRID_SIZE - 1);
        continue;
      }

      break;
    }

    if (grid->cells[y][x] == 'S') {
      printf("Hit!\n");
      grid->cells[y][x] = 'X';
      mark_ship_hit(grid, x, y);
    } else if (grid->cells[y][x] == 0) {
      printf("Miss!\n");
      grid->cells[y][x] = 'O';
    } else {
      printf("Already attacked this position.\n");
    }

    break;
  }
}

bool is_game_over(Grid *grid) {
  for (int i = 0; i < NUM_SHIPS; ++i) {
    if (!grid->ships[i].sunk) {
      return false;
    }
  }
  return true;
}

int main() {
  Grid grid;
  init_grid(&grid);

  grid.ships[0].length = 5;
  grid.ships[1].length = 4;
  grid.ships[2].length = 3;

  grid.ships[0].hits = 0;
  grid.ships[1].hits = 0;
  grid.ships[2].hits = 0;

  grid.ships[0].sunk = false;
  grid.ships[1].sunk = false;
  grid.ships[2].sunk = false;

  printf("Welcome to Battleships!\n\n");
  display_grid(&grid, false);

  for (int i = 0; i < NUM_SHIPS; ++i) {
    get_user_input_for_ship_placement(&grid, &grid.ships[i], i);
    display_grid(&grid, false);
  }

  printf("All ships placed!\nLet the game begin!\n");

  while (true) {
    display_grid(&grid, true);
    get_user_input_for_attack(&grid);
    display_grid(&grid, true);
    if (is_game_over(&grid)) {
      printf("Game over! All ships sunk!\n");
      break;
    }
  }

  for (int i = 0; i < GRID_SIZE; ++i) {
    free(grid.cells[i]);
  }
  free(grid.cells);

  return 0;
}
