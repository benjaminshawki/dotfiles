﻿class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Enter RPN expression:");
        string input = Console.ReadLine();

        try
        {
            RpnEvaluator evaluator = new RpnEvaluator(input);
            double result = evaluator.Evaluate();
            Console.WriteLine($"The result is: {result}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }
    }
}
