public class GenericStack<T> {
    private List<T> elements = new List<T>();

    public void Push(T item) {
        elements.Add(item);
    }

    public T Pop()
    {
        if (elements.Count == 0)
        {
            throw new InvalidOperationException("Stack is empty.");
        }
        T item = elements[elements.Count - 1];
        elements.RemoveAt(elements.Count - 1);
        return item;
    }

    public T Peek()
    {
        if (elements.Count == 0)
        {
            throw new InvalidOperationException("Stack is empty.");
        }
        return elements[elements.Count - 1];
    }

    public bool IsEmpty()
    {
        return elements.Count == 0;
    }
}
