public class RpnEvaluator
{
    private string[] rpnChars;
    private GenericStack<double> stack;

    public RpnEvaluator(string expression)
    {
        rpnChars = expression.Split(' ');
        stack = new GenericStack<double>();
    }

    public double Evaluate()
    {
        EvaluateRecursive(rpnChars.Length - 1);
        return stack.Pop();
    }

    private void EvaluateRecursive(int currentIndex)
    {
        if (currentIndex < 0)
        {
            return;
        }

        string rpnChar = rpnChars[currentIndex];

        if (double.TryParse(rpnChar, out double number))
        {
            stack.Push(number);
        }
        else
        {
            EvaluateRecursive(currentIndex - 1);
            double operand2 = stack.Pop();
            double operand1 = stack.Pop();
            
            double result = rpnChar switch
            {
                "+" => operand1 + operand2,
                "-" => operand1 - operand2,
                "*" => operand1 * operand2,
                "/" => operand1 / operand2,
                _ => throw new InvalidOperationException("Invalid operator")
            };

            stack.Push(result);
            return;
        }

        EvaluateRecursive(currentIndex - 1);
    }
}
