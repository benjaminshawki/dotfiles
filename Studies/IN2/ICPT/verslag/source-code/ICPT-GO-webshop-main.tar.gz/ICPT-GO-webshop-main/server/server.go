package main

import (
	"context"
	"encoding/json"
	"fmt"
	"math/rand"
	"net/http"
	"os"
	"os/signal"
	"sync"
	"syscall"
	"time"
)

type Product struct {
	Name  string `json:"name"`
	Stock int    `json:"stock"`
}

var products = []Product{
	{Name: "Apple", Stock: 10},
	{Name: "Banana", Stock: 10},
	{Name: "Orange", Stock: 10},
}

var mu sync.Mutex

func main() {
	mux := http.NewServeMux()
	mux.HandleFunc("/stock", stockHandler)
	mux.HandleFunc("/order", orderHandler)

	server := &http.Server{
		Addr:    ":8080",
		Handler: mux,
	}

	// Channel to listen for interrupt or terminate signals
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)

	go replenishStock()

	fmt.Println("Starting server on :8080")
	go func() {
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			fmt.Println("Failed to start server:", err)
		}
	}()

	// Block until a signal is received
	<-quit

	fmt.Println("Shutting down server...")
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := server.Shutdown(ctx); err != nil {
		fmt.Println("Server forced to shutdown:", err)
	}

	fmt.Println("Server exiting")
}

func stockHandler(responseWriter http.ResponseWriter, request *http.Request) {
	mu.Lock()
	defer mu.Unlock()

	productName := request.URL.Query().Get("product")

	for _, product := range products {
		if product.Name == productName {
			json.NewEncoder(responseWriter).Encode(product)
			return
		}
	}
	http.Error(responseWriter, "Product not found", http.StatusNotFound)
}

func orderHandler(responseWriter http.ResponseWriter, request *http.Request) {
	mu.Lock()
	defer mu.Unlock()

	productName := request.URL.Query().Get("product")

	for i, product := range products {
		if product.Name == productName {
			if product.Stock > 0 {
				products[i].Stock--
				json.NewEncoder(responseWriter).Encode(products[i])
				if products[i].Stock < 0 {
					fmt.Println("Stock for product", productName, "fell below 0. Shutting down server...")
					gracefulShutdown()
				}
				return
			}
			http.Error(responseWriter, "Out of stock", http.StatusConflict)
			return
		}
	}
	http.Error(responseWriter, "Product not found", http.StatusNotFound)
}

func replenishStock() {
	for {
		time.Sleep(1 * time.Second)
		mu.Lock()
		randomProductIndex := rand.Intn(len(products))
		products[randomProductIndex].Stock++
		fmt.Println("Replenished stock for", products[randomProductIndex].Name, "to", products[randomProductIndex].Stock)
		mu.Unlock()
	}
}

func gracefulShutdown() {
	// Signal the main function to shut down the server
	syscall.Kill(syscall.Getpid(), syscall.SIGINT)
}
