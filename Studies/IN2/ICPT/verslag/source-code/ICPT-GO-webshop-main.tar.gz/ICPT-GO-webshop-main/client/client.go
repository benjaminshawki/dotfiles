package main

import (
	"encoding/json"
	"fmt"
	"math/rand"
	"net/http"
	"sync"
	"time"
)

type Product struct {
	Name  string `json:"name"`
	Stock int    `json:"stock"`
}

func main() {
	products := []string{"Apple", "Banana", "Orange"}
	var waitGroup sync.WaitGroup
	outputChan := make(chan string, 100)

	numClients := 80_000

	client := &http.Client{
		Timeout: 5 * time.Second,
	}

	for i := 0; i < numClients; i++ {
		waitGroup.Add(1)
		go func(clientID int) {
			defer waitGroup.Done()
			for {
				product := products[rand.Intn(len(products))]
				if checkStockAndOrder(client, product, clientID, outputChan) {
					outputChan <- fmt.Sprintf("Client %d: Ordered %s successfully", clientID, product)
				} else {
					outputChan <- fmt.Sprintf("Client %d: Failed to order %s", clientID, product)
				}
				time.Sleep(time.Duration(rand.Intn(400)+800) * time.Millisecond)
			}
		}(i)
	}

	go func() {
		for output := range outputChan {
			fmt.Println(output)
		}
	}()

	waitGroup.Wait()
	close(outputChan)
}

func checkStockAndOrder(client *http.Client, productName string, clientID int, outputChan chan string) bool {
	response, err := client.Get("http://localhost:8080/stock?product=" + productName)
	if err != nil {
		outputChan <- fmt.Sprintf("Client %d: Error checking stock: %v", clientID, err)
		return false
	}
	defer response.Body.Close()

	if response.StatusCode != http.StatusOK {
		outputChan <- fmt.Sprintf("Client %d: Product %s not found", clientID, productName)
		return false
	}

	var product Product
	if err := json.NewDecoder(response.Body).Decode(&product); err != nil {
		outputChan <- fmt.Sprintf("Client %d: Error decoding response: %v", clientID, err)
		return false
	}

	if product.Stock == 0 {
		outputChan <- fmt.Sprintf("Client %d: %s is out of stock", clientID, productName)
		return false
	}

	response, err = client.Get("http://localhost:8080/order?product=" + productName)
	if err != nil {
		outputChan <- fmt.Sprintf("Client %d: Error placing order: %v", clientID, err)
		return false
	}
	defer response.Body.Close()

	return response.StatusCode == http.StatusOK
}
