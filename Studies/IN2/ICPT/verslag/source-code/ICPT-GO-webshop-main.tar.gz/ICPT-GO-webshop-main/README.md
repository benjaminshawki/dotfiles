Server
```bash
cd server
go run .
```

Client
```bash
cd client
go run .
```

