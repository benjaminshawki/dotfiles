#include <stdio.h>
#include <stdlib.h>

// Factorial gebaseerd op de sheets van ICPT les 2 C
unsigned long long factorial(int which) {
  int i;
  unsigned long long result = 1;

  for (i = 1; i <= which; ++i) {
    result *= i;
  }
  return result;
}

#define ZERO 0
#define NEWLINE "\n"

int main(int argc, char **argv) {
  int n = atoi(argv[1]);
  if (n < ZERO) {
    printf("Error! Factorial of a negative number doesn't exist.");
  } else {
    printf("Factorial of %d = %llu", n, factorial(n));
  }
  printf(NEWLINE);
  return ZERO;
}
